=======
Credits
=======

- Mozilla and the public suffix list maintainers
- David Wilson @dw
- Tomaž Šolc @avian2
- Philippe Ombredanne @pombredanne
- Renée Burton @KnitCode
- @vpiserchia
- Kevin Olbrich @kevin-olbrich
- Masahiro Honma @hiratara
