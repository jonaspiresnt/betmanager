import sqlite3

class Banco():

    def __init__(self):

        self.conexao = sqlite3.connect('dbserver.sqlite3')
        self.createTableUsuario()
        self.createTableSettings()
        self.createTableApostas()

    def createTableUsuario(self):
        c = self.conexao.cursor()

        c.execute("""create table if not exists usuario (
                     id integer primary key,
                     bet_user text,
                     email text,
                     serial text,
                     active text)""")
        self.conexao.commit()
        c.close()

    def createTableSettings(self):
        c = self.conexao.cursor()

        c.execute("""create table if not exists settings (
                     id integer primary key,
                     stake_localhost text,
                     stake_tipster text,
                     fast_bet text,
                     fast_cash text,
                     max_units text)""")
        self.conexao.commit()
        c.close()

    def createTableApostas(self):
        c = self.conexao.cursor()

        c.execute("""create table if not exists apostas (
                     id integer primary key,
                     tr text,
                     bg text, 
                     data text,
                     desc text,
                     ip text, 
                     desc_detalhada text,
                     odd text,
                     units text,
                     valor text)""")
        self.conexao.commit()
        c.close()
