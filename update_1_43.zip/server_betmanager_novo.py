from server_socket_novo import Server
from server_apostas import Apostas
from datetime import datetime, timedelta
from create_xls_bets import writeBet
from secret_key import SECRET_KEY
from cryptography.fernet import Fernet
import server_settings
import json
import telepot
import time


def encrypt(data):
    f = Fernet(SECRET_KEY)
    encrypted = f.encrypt(str(data).encode())
    return encrypted

class Addon(object):

    def __init__(self, stake_localhost=0, stake_tipster=0, fast_bet=1, fast_cash=1, max_units=5, criptografia=1):
        self.data = dict()
        self.stake_localhost = float(stake_localhost)
        self.stake_tipster = float(stake_tipster)
        self.max_units = float(max_units)
        self.fast_bet = fast_bet # 1 == NAO | 2 == SIM
        self.fast_cash = fast_cash # 1 == NAO | 2 == SIM
        self.criptografia = criptografia # 1 == NAO | 2 == SIM
        self.bet = None
        self.id_verificator = dict()
        self.id_verificator_fast_bet = dict()
        self.socket_server = Server()
        self.apostas = Apostas()

        self.bet_id = dict()
        self.bet_id = dict()
        self.bet_id_aux = dict()
        self.bet_id_time = dict()
        self.bet_is_suspended = dict()
        self.bet_is_suspended_time = dict()
        self.time_to_wait = dict()
        self.last_bet_url = dict()
        self.aposta = dict()
        self.fast_bet_aux = dict()
        self.bg = dict()
        self.fd = dict()
        self.md = dict()
        self.message_max_units = dict()

        self.descricao_xls = dict()
        self.descricao_xls_completa = dict()
        self.descricao_simplificada = dict()
        self.qtd_bets_xls = dict()
        self.linha_entrada = dict()
        self.handicap = dict()
        self.time = dict()

        self.headers = dict()

    def updateVariables(self, stake_localhost=0, stake_tipster=0, fast_bet=1, fast_cash=1, max_units=5, criptografia=1, cashout_dynamic=True):
        self.stake_localhost = float(stake_localhost)
        self.stake_tipster = float(stake_tipster)
        self.fast_bet = fast_bet
        self.fast_cash = fast_cash
        self.max_units = float(max_units)
        self.criptografia = criptografia

    def response(self, flow):

        if 'bet365' in flow.request.url and 'addbet' in flow.request.url:
            json_from_response = json.loads(flow.response.content)
            self.id_verificator[flow.client_conn.ip_address[0]] = json_from_response['bg']

            self.fd[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['fd']
            self.md[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['pt'][0]['md']

            try:
                self.descricao_simplificada[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['fd']
                ''' Para enviar o telegram da entrada '''
                self.linha_entrada[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['pt'][0]['bd']
                if 'ha' in json_from_response['bt'][0]['pt'][0]:
                    self.handicap[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['pt'][0]['ha']
                else:
                    self.handicap[flow.client_conn.ip_address[0]] = None
                self.time[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['pt'][0]['md']
                ''' fim do telegram '''
                self.descricao_xls_completa[flow.client_conn.ip_address[0]] = json_from_response['bt'][0]['fd']
                self.descricao_xls_completa[flow.client_conn.ip_address[0]] += ' - ' + json_from_response['bt'][0]['pt'][0]['bd'] + ': '
                self.descricao_xls_completa[flow.client_conn.ip_address[0]] += json_from_response['bt'][0]['pt'][0]['md']
                # self.qtd_bets_xls[flow.client_conn.ip_address[0]] = len(json_from_response['bt'])
            except:
                print('ADDBET: erro ao escrever no excel')
                print('\n', json_from_response)
                self.descricao_xls_completa[flow.client_conn.ip_address[0]] = None
                # self.descricao_xls_completa[flow.client_conn.ip_address[0]] = 0

        elif 'bet365' in flow.request.url and 'refreshslip' in flow.request.url:
            # ESTE METODO SERVE PARA SOBRESCREVER O ADDBET (ACIMA), CAPTURANDO AS MUDANCAS DE ODD

            json_from_response = json.loads(flow.response.content)

            self.id_verificator[flow.client_conn.ip_address[0]] = json_from_response['bg']

        elif 'bet365' in flow.request.url and 'placebet' in flow.request.url:
            print('\n\nENTREI NO PB RESPONSE')
            if self.id_verificator[flow.client_conn.ip_address[0]]:
                print('2')
                if self.id_verificator[flow.client_conn.ip_address[0]] in flow.request.url:
                    print('3')
                    json_from_response = json.loads(flow.response.content)
                    print('JSON FROM RESPONSE: ', json_from_response)
                    if 'mi' in json_from_response:
                        # self.apostas.insertAposta(9999999999, self.id_verificator_fast_bet[flow.client_conn.ip_address[0]],
                        #                           datetime.now().strftime('%H:%M'),
                        #                           self.descricao_simplificada[flow.client_conn.ip_address[0]],
                        #                           flow.client_conn.ip_address[0])
                        if 'selections_changed' in json_from_response['mi']:
                            if flow.client_conn.ip_address[0] in self.bet_is_suspended:
                                if self.data[flow.client_conn.ip_address[0]]['forms']['placebet']['form'] == self.bet_is_suspended[flow.client_conn.ip_address[0]]['form']:
                                    self.bet_is_suspended[flow.client_conn.ip_address[0]]['suspended'] = True
                            pass
                    else:
                        if 'bb' in json_from_response['bt'][0]:
                            print(json_from_response)
                            bb = json_from_response['bt'][0]['bb']
                            self.data[flow.client_conn.ip_address[0]]['bb'] = bb
                            tr_aux = str(json_from_response['bt'][0]['fi'])
                            tr_aux += str(json_from_response['bt'][0]['pt'][0]['pi'])
                            tr = tr_aux
                            print('\n\nTR AUX: ', tr)
                            self.descricao_simplificada[flow.client_conn.ip_address[0]] = 'BETBUILDER - ' + \
                                                                                          self.descricao_simplificada[
                                                                                              flow.client_conn.ip_address[
                                                                                                  0]]
                        elif 'mo' in json_from_response:
                            tr_aux = str(json_from_response['mo'][0]['tr'])
                        else:
                            tr_aux = str(json_from_response['bt'][0]['tr'])

                        tr = ''
                        for x in tr_aux:
                            if x.isdigit():
                                tr += x
                        print('TR NO PB: ', tr)

                        re = json_from_response['re']
                        ts = json_from_response['ts']

                        if 'tc' in json_from_response:
                            self.data[flow.client_conn.ip_address[0]]['tc'] = json_from_response['tc']
                        self.data[flow.client_conn.ip_address[0]]['tr'] = tr
                        self.data[flow.client_conn.ip_address[0]]['re'] = re
                        self.data[flow.client_conn.ip_address[0]]['ts'] = ts
                        self.data[flow.client_conn.ip_address[0]]['id_verificator'] = self.id_verificator[flow.client_conn.ip_address[0]]

                        stake = float(json_from_response['ts'])

                        if '127.0.0.1' in flow.client_conn.ip_address[0]:
                            units = stake / self.stake_localhost
                        else:
                            units = stake / self.stake_tipster

                        if units > self.max_units:
                            if server_settings.USE_GROUP_ENQUETES:
                                if not self.message_max_units[flow.client_conn.ip_address[0]]:
                                    try:
                                        bot = telepot.Bot(server_settings.BOT_ID)
                                        resultado = '_{}_\n\n*Valor máximo de unidades excedido.*\n*Máximo permitido:* {}'.format(
                                            self.fd[flow.client_conn.ip_address[0]], self.max_units)
                                        group_id = server_settings.GROUP_ID
                                        bot.sendMessage(group_id, resultado, parse_mode='Markdown')
                                    except:
                                        pass
                                pass
                            else:
                                pass
                        else:
                            self.data[flow.client_conn.ip_address[0]]['units'] = units
                            self.headers[flow.client_conn.ip_address[0]] = dict()

                            for x, y in flow.request.headers.items():
                                if x == 'Cookie':
                                    self.headers[flow.client_conn.ip_address[0]][x] = None
                                else:
                                    self.headers[flow.client_conn.ip_address[0]][x] = y

                            self.data[flow.client_conn.ip_address[0]]['headers'] = self.headers[flow.client_conn.ip_address[0]]

                            if self.fast_bet == 1:
                                if self.criptografia == 1:
                                    self.socket_server.sendToAll(self.data[flow.client_conn.ip_address[0]])
                                else:
                                    encrypted_data = encrypt(self.data[flow.client_conn.ip_address[0]])
                                    self.socket_server.sendToAll(encrypted_data)

                                if server_settings.USE_GROUP_TIPS:
                                    if self.handicap[flow.client_conn.ip_address[0]]:
                                        message = '*NOVA ENTRADA:*\n\n_{}_\n\n{} {}\n\n{}\n\n'.format(
                                            self.descricao_simplificada[flow.client_conn.ip_address[0]],
                                            self.linha_entrada[flow.client_conn.ip_address[0]],
                                            self.handicap[flow.client_conn.ip_address[0]],
                                            self.time[flow.client_conn.ip_address[0]]
                                        )
                                    else:
                                        message = '*NOVA ENTRADA:*\n\n_{}_\n\n{}\n\n{}\n\n'.format(
                                            self.descricao_simplificada[flow.client_conn.ip_address[0]],
                                            self.linha_entrada[flow.client_conn.ip_address[0]],
                                            self.time[flow.client_conn.ip_address[0]]
                                        )

                                    try:
                                        bot = telepot.Bot(server_settings.BOT_ID)
                                        group_id = server_settings.GROUP_TIPS_ID
                                        bot.sendMessage(group_id, message, parse_mode='Markdown')
                                    except:
                                        pass

                                print('vou por no banco de dados')
                                self.apostas.insertAposta(tr, self.id_verificator[flow.client_conn.ip_address[0]],
                                                          datetime.now().strftime('%H:%M'),
                                                          self.descricao_simplificada[flow.client_conn.ip_address[0]],
                                                          flow.client_conn.ip_address[0], self.descricao_xls_completa[flow.client_conn.ip_address[0]],
                                                          round(float(self.data[flow.client_conn.ip_address[0]]['re']) /
                                                                float(self.data[flow.client_conn.ip_address[0]]['ts']), 3),
                                                          self.data[flow.client_conn.ip_address[0]]['units'], stake)
                            else:
                                print('update a aposta')
                                self.apostas.updateAposta(self.id_verificator_fast_bet[flow.client_conn.ip_address[0]], self.descricao_simplificada[flow.client_conn.ip_address[0]], tr)
                            # if self.fast_bet == 2:
                            #     self.apostas.insertAposta(tr, self.id_verificator_fast_bet[flow.client_conn.ip_address[0]],
                            #                               datetime.now().strftime('%H:%M'),
                            #                               self.descricao_simplificada[flow.client_conn.ip_address[0]],
                            #                               flow.client_conn.ip_address[0])

                            try:
                                self.descricao_xls[flow.client_conn.ip_address[0]] = json_from_response['la'][0]['ak']
                                self.qtd_bets_xls[flow.client_conn.ip_address[0]] = len(json_from_response['bt'])
                            except:
                                if self.data[flow.client_conn.ip_address[0]]['tr']:
                                    self.descricao_xls[flow.client_conn.ip_address[0]] = 'CS:GO'
                                    self.qtd_bets_xls[flow.client_conn.ip_address[0]] = 0
                                else:
                                    print('ADDBET: erro ao escrever no excel')
                                    print('\n', json_from_response)
                                    self.descricao_xls[flow.client_conn.ip_address[0]] = None
                                    self.qtd_bets_xls[flow.client_conn.ip_address[0]] = 0

                            if self.descricao_xls[flow.client_conn.ip_address[0]]:
                                try:
                                    if self.qtd_bets_xls[flow.client_conn.ip_address[0]] == 1:
                                        tipo = 'Simples'
                                    elif self.qtd_bets_xls[flow.client_conn.ip_address[0]] == 2:
                                        tipo = 'Duplas'
                                    elif self.qtd_bets_xls[flow.client_conn.ip_address[0]] == 3:
                                        tipo = 'Triplas'
                                    else:
                                        tipo = 'Multiplas ({})'.format(self.qtd_bets_xls[flow.client_conn.ip_address[0]])
                                    hoje = datetime.today().strftime('%d/%m/%Y')
                                    my_bet_xls = [self.descricao_xls[flow.client_conn.ip_address[0]], hoje,
                                                  self.descricao_xls_completa[flow.client_conn.ip_address[0]], tipo,
                                                  round(float(self.data[flow.client_conn.ip_address[0]]['re']) /
                                                        float(self.data[flow.client_conn.ip_address[0]]['ts']), 3),
                                                  self.data[flow.client_conn.ip_address[0]]['units']]
                                    writeBet(my_bet_xls)
                                except:
                                    print('PLACEBET: erro ao escrever no excel')
                                    pass


        elif flow.request.url == 'https://www.bet365.com/BetsWebAPI/closebet':
            if self.fast_cash == 1:
                bet_id_aux = flow.request.get_text().split('&cv')[0].split('bid=')[1]
                self.bet_id[flow.client_conn.ip_address[0]]= ''

                for x in bet_id_aux:
                    if x.isdigit():
                        self.bet_id[flow.client_conn.ip_address[0]] += x

                # self.bet_id[flow.client_conn.ip_address[0]] = flow.response.get_text().split('|Bet')[0]
                # if not self.bet_id[flow.client_conn.ip_address[0]][0].isdigit():
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]][1:]
                # else:
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]
                #
                # if not self.bet_id[flow.client_conn.ip_address[0]][-1].isdigit():
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]][:-1]
                # else:
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]

                continue_in_cash = True

                '''
                if not flow.client_conn.ip_address[0] in self.bet_id_aux:
                    self.bet_id_aux[flow.client_conn.ip_address[0]] = None
                    self.bet_id_time[flow.client_conn.ip_address[0]] = None

                if self.bet_id[flow.client_conn.ip_address[0]] == self.bet_id_aux[flow.client_conn.ip_address[0]]:
                    if datetime.now() < (self.bet_id_time[flow.client_conn.ip_address[0]] + timedelta(seconds=25)):
                        continue_in_cash = False
                        pass
                    else:
                        self.bet_id_aux[flow.client_conn.ip_address[0]] = None
                else:
                    self.bet_id_time[flow.client_conn.ip_address[0]] = datetime.now()
                    self.bet_id_aux[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]
                '''

                if continue_in_cash:

                    print('SELF BET ID FAST FALSE: ', self.bet_id[flow.client_conn.ip_address[0]])

                    percentual = dict()
                    if self.aposta[flow.client_conn.ip_address[0]]:
                        self.fast_bet_aux[flow.client_conn.ip_address[0]] = True
                        self.bg[flow.client_conn.ip_address[0]] = self.aposta[flow.client_conn.ip_address[0]][2]
                        try:
                            valor_aposta = float(self.aposta[flow.client_conn.ip_address[0]][9])
                        except:
                            valor_aposta = None
                        if valor_aposta:
                            percentual[flow.client_conn.ip_address[0]] = (valor_cash / valor_aposta) - 1
                        else:
                            percentual[flow.client_conn.ip_address[0]] = 999.00
                    else:
                        self.fast_bet_aux[flow.client_conn.ip_address[0]] = False
                        self.bg[flow.client_conn.ip_address[0]] = None
                        percentual[flow.client_conn.ip_address[0]] = 999.00

                    data = {'cod': 15, 'id': self.bet_id[flow.client_conn.ip_address[0]],
                                                  'fast_bet': self.fast_bet_aux[flow.client_conn.ip_address[0]],
                                                  'bg': self.bg[flow.client_conn.ip_address[0]], 'percentual': percentual[flow.client_conn.ip_address[0]]}

                    if self.criptografia == 1:
                        self.socket_server.sendToAll(data)
                    else:
                        encrypted_data = encrypt(data)
                        self.socket_server.sendToAll(encrypted_data)

                    if server_settings.USE_GROUP_TIPS:
                        message = '*CASHOUT:*\n\n{}\n\n'.format(self.aposta[flow.client_conn.ip_address[0]][4])
                        try:
                            bot = telepot.Bot(server_settings.BOT_ID)
                            group_id = server_settings.GROUP_TIPS_ID
                            bot.sendMessage(group_id, message, parse_mode='Markdown')
                        except:
                            pass


    def request(self, flow):

        if 'bet365' in flow.request.url and 'addbet' in flow.request.url:

            self.data[flow.client_conn.ip_address[0]] = dict()
            self.data[flow.client_conn.ip_address[0]]['cod'] = 10
            self.data[flow.client_conn.ip_address[0]]['forms'] = dict()
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet'] = dict()
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet']['url'] = flow.request.url
            form = dict()
            for x in flow.request.urlencoded_form:
                form[x] = flow.request.urlencoded_form[x]
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet']['form'] = form

        elif 'bet365' in flow.request.url and 'refreshslip' in flow.request.url:

            self.data[flow.client_conn.ip_address[0]] = dict()
            self.data[flow.client_conn.ip_address[0]]['cod'] = 10
            self.data[flow.client_conn.ip_address[0]]['forms'] = dict()
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet'] = dict()
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet']['url'] = flow.request.url
            form = dict()
            for x in flow.request.urlencoded_form:
                form[x] = flow.request.urlencoded_form[x]
            self.data[flow.client_conn.ip_address[0]]['forms']['addbet']['form'] = form

        elif 'bet365' in flow.request.url and 'placebet' in flow.request.url:

            self.data[flow.client_conn.ip_address[0]]['forms']['placebet'] = dict()
            form = dict()
            for x in flow.request.urlencoded_form:
                form[x] = flow.request.urlencoded_form[x]

            self.data[flow.client_conn.ip_address[0]]['forms']['placebet']['form'] = form

            self.message_max_units[flow.client_conn.ip_address[0]] = False

            if self.fast_bet == 2:

                if not flow.client_conn.ip_address[0] in self.last_bet_url:
                    self.last_bet_url[flow.client_conn.ip_address[0]] = None

                if self.last_bet_url[flow.client_conn.ip_address[0]] == flow.request.url and '127.0.0.1' in flow.client_conn.ip_address[0]:
                    pass
                else:
                    self.last_bet_url[flow.client_conn.ip_address[0]] = flow.request.url

                    print(flow.client_conn.ip_address[0], '\n>>> ', self.last_bet_url[flow.client_conn.ip_address[0]])

                    try:
                        if 'ms' in self.data[flow.client_conn.ip_address[0]]['forms']['placebet']['form']:
                            string = self.data[flow.client_conn.ip_address[0]]['forms']['placebet']['form']['ms']
                        else:
                            string = self.data[flow.client_conn.ip_address[0]]['forms']['placebet']['form']['ns']
                        string = string.split('#st=')[1]

                        if '#tr=' in string:
                            string = string.split('#||')[0]
                            re = string.split('#tr=')[1]
                            ts = string.split('#tr')[0]
                        else:
                            re = '1'
                            ts = string.split('#')[0]

                        self.data[flow.client_conn.ip_address[0]]['fast_bet'] = True
                        self.data[flow.client_conn.ip_address[0]]['tr'] = 9999999999
                        self.data[flow.client_conn.ip_address[0]]['re'] = re
                        self.data[flow.client_conn.ip_address[0]]['ts'] = ts
                        self.data[flow.client_conn.ip_address[0]]['id_verificator'] = self.id_verificator[flow.client_conn.ip_address[0]]

                        stake = float(ts)

                        if '127.0.0.1' in flow.client_conn.ip_address[0]:
                            units = stake / self.stake_localhost
                            # if flow.client_conn.ip_address[0] in self.md:
                            #     if 'escanteio' in self.md[flow.client_conn.ip_address[0]].lower() or 'canto' in self.md[flow.client_conn.ip_address[0]].lower():
                            #         bot = telepot.Bot("1350695459:AAHR-7NYpX_R3vUNC7zxFLdErrOzvbfOhY4")
                            #         resultado = '_{}_\n\n*Entrada em Escanteios.*'.format(
                            #             self.fd[flow.client_conn.ip_address[0]])
                            #         group_id = -1001406198697
                            #         bot.sendMessage(group_id, resultado, parse_mode='Markdown')
                            #         pass
                            #     else:
                            #         pass
                        else:
                            units = stake / self.stake_tipster

                        if units > self.max_units:
                            if server_settings.USE_GROUP_ENQUETES:
                                bot = telepot.Bot(server_settings.BOT_ID)
                                group_id = server_settings.GROUP_ID
                                resultado = '_{}_\n\n*Valor máximo de unidades excedido.*\n*Máximo permitido:* {}'.format(
                                    self.fd[flow.client_conn.ip_address[0]], self.max_units)
                                bot.sendMessage(group_id, resultado, parse_mode='Markdown')
                                self.message_max_units[flow.client_conn.ip_address[0]] = True
                            pass

                        else:
                            self.id_verificator_fast_bet[flow.client_conn.ip_address[0]] = self.id_verificator[flow.client_conn.ip_address[0]]
                            self.data[flow.client_conn.ip_address[0]]['units'] = units

                            self.headers[flow.client_conn.ip_address[0]] = dict()

                            for x, y in flow.request.headers.items():
                                if x == 'Cookie':
                                    self.headers[flow.client_conn.ip_address[0]][x] = None
                                else:
                                    self.headers[flow.client_conn.ip_address[0]][x] = y
                            self.data[flow.client_conn.ip_address[0]]['headers'] = self.headers[flow.client_conn.ip_address[0]]
                            print('\n\n\nENVIAREI: \n', self.data[flow.client_conn.ip_address[0]])
                            if self.criptografia == 1:
                                self.socket_server.sendToAll(self.data[flow.client_conn.ip_address[0]])
                            else:
                                encrypted_data = encrypt(self.data[flow.client_conn.ip_address[0]])
                                self.socket_server.sendToAll(encrypted_data)

                            if server_settings.USE_GROUP_TIPS:

                                if self.handicap[flow.client_conn.ip_address[0]]:
                                    message = '*NOVA ENTRADA:*\n\n_{}_\n\n{} {}\n\n{}\n\n'.format(
                                        self.descricao_simplificada[flow.client_conn.ip_address[0]], self.linha_entrada[flow.client_conn.ip_address[0]],
                                        self.handicap[flow.client_conn.ip_address[0]], self.time[flow.client_conn.ip_address[0]]
                                    )
                                else:
                                    message = '*NOVA ENTRADA:*\n\n_{}_\n\n{}\n\n{}\n\n'.format(
                                        self.descricao_simplificada[flow.client_conn.ip_address[0]], self.linha_entrada[flow.client_conn.ip_address[0]],
                                        self.time[flow.client_conn.ip_address[0]]
                                    )

                                try:
                                    bot = telepot.Bot(server_settings.BOT_ID)
                                    group_id = server_settings.GROUP_TIPS_ID
                                    bot.sendMessage(group_id, message, parse_mode='Markdown')
                                except:
                                    pass

                            self.apostas.insertAposta(9999999999, self.id_verificator_fast_bet[flow.client_conn.ip_address[0]],
                                                      datetime.now().strftime('%H:%M'),
                                                      self.descricao_simplificada[flow.client_conn.ip_address[0]],
                                                      flow.client_conn.ip_address[0], self.descricao_xls_completa[flow.client_conn.ip_address[0]],
                                                      round(float(self.data[flow.client_conn.ip_address[0]]['re']) /
                                                            float(self.data[flow.client_conn.ip_address[0]]['ts']), 3),
                                                      self.data[flow.client_conn.ip_address[0]]['units'], stake)
                    except:
                        print('no except do placebet do socket novo')
                        self.last_bet_url[flow.client_conn.ip_address[0]] = None

        elif flow.request.url == 'https://www.bet365.com/BetsWebAPI/closebet':

            # self.socket_server.sendToAll({'cod': 15, 'id': 'Q684583152379513705F',
            #                               'fast_bet': True,
            #                               'bg': '9121b192-67ac-443c-b97a-ca5c04964623'})

            if self.fast_cash == 2:
                valor_cash_aux = flow.request.get_text().split('&cv=')[1].split('&cm')[0]
                valor_cash = float(valor_cash_aux)
                print('\n\nVALOR: ', valor_cash)

                bet_id_aux = flow.request.get_text().split('&cv')[0].split('bid=')[1]
                # self.bet_id[flow.client_conn.ip_address[0]] = flow.request.get_text().split('&cv')[0].split('bid=')[1]
                print('fast cash')
                print(bet_id_aux)
                # self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]].split('bid=')[1]
                self.bet_id[flow.client_conn.ip_address[0]]= ''

                for x in bet_id_aux:
                    if x.isdigit():
                        self.bet_id[flow.client_conn.ip_address[0]] += x
                #
                # if not self.bet_id[flow.client_conn.ip_address[0]][0].isdigit():
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]][1:]
                # else:
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]
                #
                # if not self.bet_id[flow.client_conn.ip_address[0]][-1].isdigit():
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]][:-1]
                # else:
                #     self.bet_id[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]
                print('bet-id: ', self.bet_id[flow.client_conn.ip_address[0]])
                continue_in_cash = True

                '''
                if not flow.client_conn.ip_address[0] in self.bet_id_aux:
                    self.bet_id_aux[flow.client_conn.ip_address[0]] = None
                    self.bet_id_time[flow.client_conn.ip_address[0]] = None

                if self.bet_id[flow.client_conn.ip_address[0]] == self.bet_id_aux[flow.client_conn.ip_address[0]]:
                    if datetime.now() < (self.bet_id_time[flow.client_conn.ip_address[0]] + timedelta(seconds=35)):
                        continue_in_cash = False
                        pass
                    else:
                        self.bet_id_aux[flow.client_conn.ip_address[0]] = None
                else:
                    self.bet_id_time[flow.client_conn.ip_address[0]] = datetime.now()
                    self.bet_id_aux[flow.client_conn.ip_address[0]] = self.bet_id[flow.client_conn.ip_address[0]]
                '''

                if continue_in_cash:

                    self.aposta[flow.client_conn.ip_address[0]] = self.apostas.selectAposta(self.bet_id[flow.client_conn.ip_address[0]])

                    print('SELF APOSTA: ', self.aposta[flow.client_conn.ip_address[0]])
                    percentual = dict()
                    if self.aposta[flow.client_conn.ip_address[0]]:
                        self.fast_bet_aux[flow.client_conn.ip_address[0]] = True
                        self.bg[flow.client_conn.ip_address[0]] = self.aposta[flow.client_conn.ip_address[0]][2]
                        try:
                            valor_aposta = float(self.aposta[flow.client_conn.ip_address[0]][9])
                        except:
                            valor_aposta = None
                        if valor_aposta:
                            percentual[flow.client_conn.ip_address[0]] = (valor_cash / valor_aposta) - 1
                        else:
                            percentual[flow.client_conn.ip_address[0]] = 999.00
                    else:
                        self.fast_bet_aux[flow.client_conn.ip_address[0]] = False
                        self.bg[flow.client_conn.ip_address[0]] = None
                        percentual[flow.client_conn.ip_address[0]] = 999.00

                    data = {'cod': 15, 'id': self.bet_id[flow.client_conn.ip_address[0]],
                                                  'fast_bet': self.fast_bet_aux[flow.client_conn.ip_address[0]],
                                                  'bg': self.bg[flow.client_conn.ip_address[0]], 'percentual': percentual[flow.client_conn.ip_address[0]]}

                    if self.criptografia == 1:
                        self.socket_server.sendToAll(data)
                    else:
                        encrypted_data = encrypt(data)
                        self.socket_server.sendToAll(encrypted_data)

                    if server_settings.USE_GROUP_TIPS:
                        message = '*CASHOUT:*\n\n{}\n\n'.format(self.aposta[flow.client_conn.ip_address[0]][4])
                        try:
                            bot = telepot.Bot(server_settings.BOT_ID)
                            group_id = server_settings.GROUP_TIPS_ID
                            bot.sendMessage(group_id, message, parse_mode='Markdown')
                        except:
                            pass


    def sendCashoutToAll(self, data):
        for x in range(5):
            print('X: ', x)
            if self.criptografia == 1:
                self.socket_server.sendToAll(data)
            else:
                encrypted_data = encrypt(data)
                self.socket_server.sendToAll(encrypted_data)
            time.sleep(3)
