from server_banco import Banco

class Settings(object):

    def __init__(self, stake_localhost=0, stake_tipster=0, fast_bet=1, fast_cash=1, max_units=5, criptografia=1, cashout_dynamic=True):
        self.stake_localhost = stake_localhost
        self.stake_tipster = stake_tipster
        self.fast_bet = fast_bet
        self.fast_cash = fast_cash
        self.max_units = max_units
        self.criptografia = criptografia
        self.cashout_dynamic = cashout_dynamic

    def insertSettings(self, id):

        db = Banco()
        try:
            c = db.conexao.cursor()
            sql = 'INSERT INTO settings (id, stake_localhost, stake_tipster, fast_bet, fast_cash, max_units, criptografia, cashout_dynamic) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
            c.execute(sql, (id, self.stake_localhost, self.stake_tipster, self.fast_bet, self.fast_cash, self.max_units, self.criptografia, self.cashout_dynamic))
            db.conexao.commit()
            c.close()
            return True
        except:
            return False

    def updateSettings(self, id):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'UPDATE settings SET stake_localhost=?, stake_tipster=?, fast_bet=?, fast_cash=?, max_units=?, criptografia=?, cashout_dynamic=? WHERE id=?'
            c.execute(sql, (self.stake_localhost, self.stake_tipster, self.fast_bet, self.fast_cash, self.max_units, self.criptografia, self.cashout_dynamic, id))
            db.conexao.commit()
            c.execute('SELECT * FROM settings;')
            c.fetchall()
            c.close()

            return True
        except:
            return False


    def selectSettings(self, id):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'SELECT * FROM settings WHERE id=?;'
            c.execute(sql, (id,))

            for linha in c:
                find = True
                self.id = linha[0]
                self.stake_localhost = linha[1]
                self.stake_tipster = linha[2]
                self.fast_bet = linha[3]
                self.fast_cash = linha[4]
                self.max_units = linha[5]
                self.criptografia = linha[6]
                self.cashout_dynamic = linha[7]
                break
            else:
                find = False

            c.close()

            if find:
                return True
            else:
                return False
        except:
            return False