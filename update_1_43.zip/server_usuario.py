from server_banco import Banco


class Usuario(object):

    def __init__(self, bet_user='', email='', serial='', active='true'):
        print('HERE NO USUARIO')
        self.bet_user = bet_user
        self.email = email
        self.serial = serial
        self.active = active

    def insertUser(self):

        db = Banco()
        try:
            c = db.conexao.cursor()
            sql = 'INSERT INTO usuario (bet_user, email, serial, active) VALUES (?, ?, ?, ?)'
            c.execute(sql, (self.bet_user, self.email, self.serial, self.active))
            db.conexao.commit()
            c.close()

            return True
        except:
            return False

    def updateUser(self, id):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'UPDATE usuario SET bet_user=?, email=?, serial=? active=? WHERE email=?'
            c.execute(sql, (self.bet_user, self.email, self.serial, self.active, self.email))
            db.conexao.commit()
            c.close()

            return True
        except:
            return False


    def selectUser(self):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'SELECT * FROM usuario WHERE bet_user=? AND email=? AND serial=? AND active=?;'
            c.execute(sql, (self.bet_user, self.email, self.serial, 'true'))
            query = c.fetchone()
            c.close()
            if not query:
                return False
            return True

        except:
            return False
