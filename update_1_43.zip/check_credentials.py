from server_banco import Banco
import pickle


def checkCredentials(data):

    try:
        file = open('version.txt', 'r')
        line = file.readline()
        file.close()
        version = float(line)
    except:
        version = 1.0

    db = Banco()

    c = db.conexao.cursor()
    # if data['serial'].strip() == 'GFAGnEo3uFfkjLv8' and data['email'].strip() == 'virtus@admdecontas.com.br':
    #     sql = 'SELECT * FROM usuario WHERE email=? COLLATE NOCASE AND serial=? COLLATE NOCASE AND active=?;'
    #     c.execute(sql, (data['email'].strip(), data['serial'].strip(), 'true'))
    #     user = c.fetchone()
    # else:
    #     sql = 'SELECT * FROM usuario WHERE email=? COLLATE NOCASE AND serial=? COLLATE NOCASE AND bet_user=? COLLATE NOCASE AND active=?;'
    #     c.execute(sql, (data['email'].strip(), data['serial'].strip(), data['bet_user'].strip(), 'true'))
    #     user = c.fetchone()
    sql = 'SELECT * FROM usuario WHERE email=? COLLATE NOCASE AND serial=? COLLATE NOCASE AND bet_user=? COLLATE NOCASE AND active=?;'
    c.execute(sql, (data['email'].strip(), data['serial'].strip(), data['bet_user'].strip(), 'true'))
    user = c.fetchone()
    print(user, ' - ', data['bet_user'].strip())
    sql = 'SELECT cashout_dynamic FROM settings WHERE id=?;'
    c.execute(sql, (1,))
    cashout_dynamic = c.fetchone()[0]
    # if user:
    #     if data['cod'] == 51:
    #         return {'cod': 202, 'response': 'ok'}
    #     return {'cod': 201, 'response': 'ok'}
    # return {'cod': 211, 'response': 'false'}
    # #
    if user:
        if data['cod'] == 51:
            response = {'cod': 202, 'response': 'ok', 'get_cashout_dynamic': cashout_dynamic, 'version': version}
        else:
            response = {'cod': 201, 'response': 'ok', 'get_cashout_dynamic': cashout_dynamic, 'version': version}
    else:
        response = {'cod': 211, 'response': 'false'}
    return pickle.dumps(response)