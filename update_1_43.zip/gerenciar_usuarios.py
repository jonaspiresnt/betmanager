from server_banco import Banco

def insertManyUser():

    while True:
        bet_user = input('Bet User: ')
        if bet_user.lower() == 'sair':
            return True
        email =    input('E-mail  : ')
        serial =   input('Serial  : ')
        active = 'true'

        db = Banco()
        try:
            c = db.conexao.cursor()
            sql = 'INSERT INTO usuario (bet_user, email, serial, active) VALUES (?, ?, ?, ?)'
            c.execute(sql, (bet_user, email, serial, active))
            db.conexao.commit()
            c.close()
            print('Usuário cadastrado com sucesso.')
        except:
            print('Falha em cadastrar Usuário')

def insertUser():

    bet_user = input('Bet User: ')
    email =    input('E-mail  : ')
    serial =   input('Serial  : ')
    active = 'true'

    db = Banco()
    try:
        c = db.conexao.cursor()
        sql = 'INSERT INTO usuario (bet_user, email, serial, active) VALUES (?, ?, ?, ?)'
        c.execute(sql, (bet_user, email, serial, active))
        db.conexao.commit()
        c.close()
        print('Usuário cadastrado com sucesso.')
        return True
    except:
        return False

def updateUser():

    id = input('Informe o ID do usuário que deseja alterar: ')

    db = Banco()

    try:
        c = db.conexao.cursor()
        sql = 'SELECT * FROM usuario WHERE id=?;'
        c.execute(sql, (id,))
        query = c.fetchall()
        c.close()
        if not query:
            print('Usuário não encontrado.')
            return
        for usuario in query:
            print('\nID      : ', usuario[0])
            print('Bet User: ', usuario[1])
            print('E-mail  : ', usuario[2])
            print('Serial  : ', usuario[3])
            print('Active  : ', usuario[4], '\n')
    except:
        pass

    bet_user = input('Bet User: ')
    email =    input('E-mail  : ')
    serial =   input('Serial  : ')

    try:
        c = db.conexao.cursor()
        sql = 'UPDATE usuario SET bet_user=?, email=?, serial=? WHERE id=?'
        c.execute(sql, (bet_user, email, serial, id))
        db.conexao.commit()
        c.close()
        print('Usuário alterado com sucesso.')
        return True
    except:
        return False


def listUsers():

    db = Banco()

    try:
        c = db.conexao.cursor()
        sql = 'SELECT * FROM usuario;'
        c.execute(sql)
        query = c.fetchall()
        c.close()
        if not query:
            print('Sem usuários cadastrados.')
            return
        for usuario in query:
            print('ID      : ', usuario[0])
            print('Bet User: ', usuario[1])
            print('E-mail  : ', usuario[2])
            print('Serial  : ', usuario[3])
            print('Active  : ', usuario[4], '\n')
        print('Total: ', len(query))

    except:
        return False
