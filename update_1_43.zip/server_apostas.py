from server_banco import Banco


class Apostas(object):

    def insertAposta(self, tr, bg, data, desc, ip, desc_detalhada, odd, units, valor):

        db = Banco()
        try:
            c = db.conexao.cursor()
            sql = 'INSERT INTO apostas (tr, bg, data, desc, ip, desc_detalhada, odd, units, valor) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);'
            c.execute(sql, (tr, bg, data, desc, ip, desc_detalhada, odd, units, valor))
            db.conexao.commit()
            c.close()

            return True
        except:
            return False

    def selectAposta(self, tr):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'SELECT * FROM apostas WHERE tr=?;'
            c.execute(sql, (tr,))
            query = c.fetchone()
            c.close()
            if not query:
                return False
            return query

        except:
            return False

    def updateAposta(self, bg, desc, tr):

        db = Banco()

        try:
            c = db.conexao.cursor()
            sql = 'UPDATE apostas SET tr=?, desc=? WHERE bg=?;'
            c.execute(sql, (tr, desc, bg))
            db.conexao.commit()
            c.close()

            return True
        except:
            return False
