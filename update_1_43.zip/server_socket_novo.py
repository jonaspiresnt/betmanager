from check_credentials import checkCredentials
import select, socket, pickle
import threading
import time
import telepot
import server_settings


class Server():
    def __init__(self):
        self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server.setblocking(0)
        self.server.bind(('0.0.0.0', server_settings.PORT_SOCKET))
        self.server.listen(5)
        self.inputs = [self.server]
        self.outputs = []
        self.readable = []
        self.writable = []
        self.exceptional = []
        self.connecteds = []

        self.result = dict()
        self.result_total = dict()
        self.result_cash = dict()
        self.result_cash_total = dict()

        accept = threading.Thread(target=self.acceptCon)
        accept.daemon = True
        accept.start()

        # a = threading.Thread(target=self.printOutputs)
        # a.daemon = True
        # a.start()

    def getConnecteds(self):
        return len(self.connecteds)

    def getListClients(self):
        return self.connecteds

    def printOutputs(self):
        cont = 0
        while True:
            cont += 1
            time.sleep(10)

    def acceptCon(self):

        while self.inputs:
            self.readable, self.writable, self.exceptional = select.select(
                self.inputs, self.outputs, self.inputs)
            cont = 0
            for s in self.readable:
                if s is self.server:
                    connection, client_address = s.accept()
                    connection.setblocking(0)
                    self.inputs.append(connection)
                else:
                    if s not in self.outputs:
                        self.outputs.append(s)
                    try:
                        data = s.recv(8192)
                    except (ConnectionResetError, ConnectionAbortedError, ConnectionError, ConnectionRefusedError):
                        self.outputs.remove(s)
                        self.inputs.remove(s)
                        for x in self.connecteds:
                            if x['ip'] == s.getpeername()[0] and x['port'] == s.getpeername()[1]:
                                self.connecteds.remove(x)
                    else:
                        if data:
                            try:
                                data = pickle.loads(data)
                            except:
                                pass
                            else:
                                # print('DATA NO SERVER SOCKET: ', data)
                                if data == 'exit':
                                    try:
                                        print('EXIT: ', s.getpeername())
                                        try:
                                            self.outputs.remove(s)
                                        except:
                                            pass
                                        try:
                                            self.inputs.remove(s)
                                        except:
                                            pass
                                        for x in self.connecteds:
                                            if x['ip'] == s.getpeername()[0] and x['port'] == s.getpeername()[1]:
                                                print('tem')
                                                try:
                                                    self.connecteds.remove(x)
                                                except:
                                                    pass
                                    except:
                                        pass

                                # Código 5 (conexão) ou código 51 (reconexão)
                                elif data['cod'] == 5 or data['cod'] == 51:
                                    try:
                                        check = checkCredentials(data)
                                    except:
                                        pass
                                    else:
                                        check = pickle.loads(check)
                                        s.send(pickle.dumps(check))
                                        if check['cod'] == 211:
                                            try:
                                                self.outputs.remove(s)
                                            except:
                                                pass
                                            try:
                                                self.inputs.remove(s)
                                            except:
                                                pass
                                            for x in self.connecteds:
                                                if x['ip'] == s.getpeername()[0] and x['port'] == s.getpeername()[1]:
                                                    try:
                                                        self.connecteds.remove(x)
                                                    except:
                                                        pass
                                        else:
                                            if 'version' in data:
                                                version = data['version']
                                            else:
                                                version = ' <= 1.1'
                                            self.connecteds.append({'bet_user': data['bet_user'], 'ip': s.getpeername()[0],
                                                                    'port': s.getpeername()[1], 'version': version, 'stake': data['stake']})

                                elif data['cod'] == 6 or data['cod'] == 61: # Código 6 (sucesso na aposta) ou código 61 (Falha na aposta)
                                    if not data['bg'] in self.result:
                                        self.result[data['bg']] = dict()
                                        self.result[data['bg']]['success'] = 0
                                        self.result[data['bg']]['fail'] = 0
                                        if server_settings.USE_GROUP_ENQUETES:
                                            t = threading.Thread(target=self.computeResult, args=(data['bg'], data['fd']))
                                            t.daemon = True
                                            t.start()

                                    if not data['bg'] in self.result_total:
                                        self.result_total[data['bg']] = 0

                                    if data['cod'] == 6:
                                        self.result[data['bg']]['success'] += 1
                                    elif data['cod'] == 61:
                                        self.result[data['bg']]['fail'] += 1

                                elif data['cod'] == 62: # Código 62 (total de apostas)
                                    if not data['bg'] in self.result_total:
                                        self.result_total[data['bg']] = 0
                                    self.result_total[data['bg']] += 1

                                elif data['cod'] == 65 or data['cod'] == 66: # Código 65 (sucesso no cash) ou código 66 (Falha no cash)
                                    if not data['bg'] in self.result_cash:
                                        self.result_cash[data['bg']] = dict()
                                        self.result_cash[data['bg']]['success'] = 0
                                        self.result_cash[data['bg']]['fail'] = 0
                                        if server_settings.USE_GROUP_ENQUETES:
                                            t = threading.Thread(target=self.computeCash, args=(data['bg'], data['fd']))
                                            t.daemon = True
                                            t.start()

                                    if not data['bg'] in self.result_cash_total:
                                        self.result_cash_total[data['bg']] = 0

                                    if data['cod'] == 65:
                                        self.result_cash[data['bg']]['success'] += 1
                                    elif data['cod'] == 66:
                                        self.result_cash[data['bg']]['fail'] += 1

                                elif data['cod'] == 64: # Código 64 (TOTAL: cash out)
                                    if not data['bg'] in self.result_cash_total:
                                        self.result_cash_total[data['bg']] = 0
                                    self.result_cash_total[data['bg']] += 1

                                elif data['cod'] == 63: # Alerta de Questionario da BET365 do cliente
                                    self.alertAboutClient(data['bet_user'])

    def computeCash(self, bg, fd):
        try:
            time.sleep(2)
            bot = telepot.Bot(server_settings.BOT_ID)
            group_id = server_settings.GROUP_ID

            resultado = '<i>CASHOUT:\n{}</i>\n\n<b>Total:</b> {}\n<b>Sucesso:</b> {}\n<b>Falha:</b> {}'.format(fd, self.result_cash_total[bg],
                                                                          self.result_cash[bg]['success'],
                                                                          self.result_cash[bg]['fail'])

            sent = bot.sendMessage(group_id, resultado, parse_mode='HTML')
            edited = telepot.message_identifier(sent)
            total = self.result_cash_total[bg]
            success = self.result_cash[bg]['success']
            fail = self.result_cash[bg]['fail']
            for x in range(0,20):
                if self.result_cash[bg]['success'] != success or self.result_cash[bg]['fail'] != fail or self.result_cash_total[bg] != total:
                    resultado = '<i>CASHOUT: {}</i>\n\n<b>Total:</b> {}\n<b>Sucesso:</b> {}\n<b>Falha:</b> {}'.format(fd, self.result_cash_total[bg],
                                                                                  self.result_cash[bg]['success'],
                                                                                  self.result_cash[bg]['fail'])
                    bot.editMessageText(edited, resultado, parse_mode='HTML')
                    total = self.result_cash_total[bg]
                    success = self.result_cash[bg]['success']
                    fail = self.result_cash[bg]['fail']
                time.sleep(1)
            self.result_cash.pop(bg, None)
        except:
            pass

    def computeResult(self, bg, fd):
        try:
            time.sleep(2)
            bot = telepot.Bot(server_settings.BOT_ID)
            group_id = server_settings.GROUP_ID

            resultado = '<i>{}</i>\n\n<b>Total:</b> {}\n<b>Pegou:</b> {}\n<b>Não Pegou:</b> {}'.format(fd, self.result_total[bg],
                                                                          self.result[bg]['success'],
                                                                          self.result[bg]['fail'])

            sent = bot.sendMessage(group_id, resultado, parse_mode='HTML')
            edited = telepot.message_identifier(sent)
            total = self.result_total[bg]
            success = self.result[bg]['success']
            fail = self.result[bg]['fail']
            for x in range(0,30):
                if self.result[bg]['success'] != success or self.result[bg]['fail'] != fail or self.result_total[bg] != total:
                    resultado = '<i>{}</i>\n\n<b>Total:</b> {}\n<b>Pegou:</b> {}\n<b>Não Pegou:</b> {}'.format(fd, self.result_total[bg],
                                                                                  self.result[bg]['success'],
                                                                                  self.result[bg]['fail'])
                    bot.editMessageText(edited, resultado, parse_mode='HTML')
                    total = self.result_total[bg]
                    success = self.result[bg]['success']
                    fail = self.result[bg]['fail']
                time.sleep(1)
        except:
            pass

    def alertAboutClient(self, bet_user):
        try:
            bot = telepot.Bot(server_settings.BOT_ID)
            group_id = server_settings.GROUP_ID
            mensagem = '<i>ATENÇÃO</i>\n\nO usuário <b>{}</b> precisa responder o questionário da Bet365.'.format(bet_user)
            sent = bot.sendMessage(group_id, mensagem, parse_mode='HTML')
        except:
            pass

    def sendToAll(self, msg):
        offlines = []
        for s in self.outputs:
            try:
                s.send(pickle.dumps(msg))
            except ConnectionResetError:
                print('no exception ConnectionResetError')
                offlines.append(s)
            except:
                print('no exception Geral do server socket')
                offlines.append(s)
        if offlines:
            for x in offlines:
                try:
                    self.outputs.remove(x)
                except:
                    pass
                for y in self.connecteds:
                    if y['ip'] == x.getpeername()[0] and y['port'] == x.getpeername()[1]:
                        try:
                            self.connecteds.remove(y)
                        except:
                            pass
