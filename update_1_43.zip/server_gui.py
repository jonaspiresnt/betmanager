import tkinter
from tkinter import scrolledtext
from tkinter import ttk
import sys
import time
from server_betmanager_novo import Addon
from server_settings_db import Settings
from mitmproxy.options import Options
from mitmproxy.proxy.config import ProxyConfig
from mitmproxy.proxy.server import ProxyServer
from mitmproxy.tools.dump import DumpMaster
from mitmproxy.addons import block
from secret_key import SECRET_KEY
from cryptography.fernet import Fernet
import server_settings
import threading
import asyncio
import socket
import os
import sqlite3
import telepot

def encrypt(data):
    f = Fernet(SECRET_KEY)
    encrypted = f.encrypt(str(data).encode())
    return encrypted

def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        IP = s.getsockname()[0]
    except Exception:
        IP = '127.0.0.1'
    finally:
        s.close()
    return IP

class Prox(tkinter.Entry):
    '''A Entry widget that only accepts digits'''
    def __init__(self, master=None, textvariable=None, **kwargs):
        self.var = textvariable
        self.var.trace('w', self.validate)
        tkinter.Entry.__init__(self, master, textvariable=self.var, **kwargs)
        self.get, self.set = self.var.get, self.var.set
    def validate(self, *args):
        value = self.get()
        if not value.isdigit():
            self.set(''.join(x for x in value if x.isdigit()))

class GuiPart(tkinter.Frame):

    def __init__(self, master, image_path):

        super().__init__()

        self.my_ip = get_ip()
        self.my_port = server_settings.PORT_PROXY
        self.master = master
        self.settings = Settings()
        self.server = None
        self.started = False
        self.connecteds_aux = 0
        self.new_window = None
        self.image_path = image_path
        self.list_cash = None
        self.cash_id = None
        self.cash_bg = None
        self.personalizada = False
        self.time = None
        self.last_cash = None

        has_settings = self.settings.selectSettings(id=1)
        if not has_settings:
            self.settings.insertSettings(id=1)
        self.initUI()

    def listClientsConnecteds(self):
        if self.started:
            try:
                if self.new_window.state() == "normal":
                    self.new_window.focus()
            except:
                self.new_window = tkinter.Toplevel(self.master)
                self.new_window.title('Lista de clientes conectados')
                self.new_window.geometry('670x520+630+50')
                p1 = tkinter.PhotoImage(file=self.image_path)
                self.new_window.iconphoto(False, p1)
                area = scrolledtext.ScrolledText(
                    master=self.new_window,
                    wrap=tkinter.WORD,
                    width=20,
                    height=10
                )
                area.pack(padx=10, pady=10, fill=tkinter.BOTH, expand=True)
                clients_aux = self.server.socket_server.getListClients()
                clients = clients_aux.copy()
                lista_user = []
                for x in clients:
                    lista_user.append(x['bet_user'].lower())
                lista_user.sort()
                first = True
                for y in lista_user:
                    for x in clients:
                        if x['bet_user'].lower() == y.lower():
                            if 'stake' in x:
                                string = '=== {}\n    IP: {} | Porta: {} | Versão: {} | Stake: R$ {},00\n'.format(
                                    x['bet_user'], x['ip'], x['port'], x['version'], x['stake'])
                            else:
                                string = '=== {}\n    IP: {} | Porta: {} | Versão: {} | Stake: NaN\n'.format(
                                    x['bet_user'], x['ip'], x['port'], x['version'])
                            area.insert(tkinter.END, string)
                            clients.remove(x)
                            break

    def getClientsConnecteds(self):
        connecteds = self.server.socket_server.getConnecteds()
        if connecteds != self.connecteds_aux:
            if connecteds == 1:
                self.label_04['text'] = ''
                user = ' Usuário Conectado'
                self.label_04['text'] = str(connecteds) + user
                self.label_04.configure(foreground='green')
            elif connecteds > 1:
                self.label_04['text'] = ''
                user = ' Usuários Conectados'
                self.label_04['text'] = str(connecteds) + user
                self.label_04.configure(foreground='green')
            else:
                self.label_04['text'] = ''
                user = ' Usuários Conectados'
                self.label_04['text'] = str(connecteds) + user
                self.label_04.configure(foreground='red')
            self.connecteds_aux = connecteds
        self.master.after(5000, self.getClientsConnecteds)

    def initUI(self):

        self.master.title("BetManager Server | 1.0")
        self.pack(fill=tkinter.BOTH, expand=True, pady=5, padx=5)

        # label_0 = tkinter.Label(self, text="BetManager Server", width=20, font=("bold", 20))
        # label_0.place(x=0, y=10)
        self.label_03 = tkinter.Label(self, text='Meu IP: ' + self.my_ip + ':' + str(self.my_port), font=("bold", 14))
        self.label_03.place(x=10, y=10)
        self.label_03.configure(foreground='blue')
        self.label_02 = tkinter.Label(self, text="Offline", font=("bold", 16))
        self.label_02.place(x=370, y=10)
        self.label_02.configure(foreground='red')
        self.label_01 = tkinter.Label(self, text="", font=("regular", 10))
        self.label_01.place(x=20, y=40)
        label_1 = tkinter.Label(self, text="Stake Localhost", font=("bold", 10))
        label_1.place(x=10, y=70)
        ventry_1 = tkinter.StringVar(self, value=self.settings.stake_localhost)
        self.entry_1 = Prox(self, textvariable=ventry_1, justify='right')
        self.entry_1.place(x=10, y=95)

        label_2 = tkinter.Label(self, text="Stake Tipster", font=("bold", 10))
        label_2.place(x=180, y=70)
        ventry_2 = tkinter.StringVar(self, value=self.settings.stake_tipster)
        self.entry_2 = Prox(self, textvariable=ventry_2, justify='right')
        self.entry_2.place(x=180, y=95)

        label_3 = tkinter.Label(self, text="Max Units", font=("bold", 10))
        label_3.place(x=350, y=70)
        ventry_3 = tkinter.StringVar(self, value=self.settings.max_units)
        self.entry_3 = Prox(self, textvariable=ventry_3, justify='right')
        self.entry_3.place(x=350, y=95)

        label_4 = tkinter.Label(self, text="Aposta rápida", font=("bold", 10))
        label_4.place(x=10, y=140)
        self.var = tkinter.IntVar()
        tkinter.Radiobutton(self, text="Não", padx=5, variable=self.var, value=1).place(x=135, y=140)
        tkinter.Radiobutton(self, text="Sim", padx=20, variable=self.var, value=2).place(x=190, y=140)
        self.var.set(self.settings.fast_bet)

        label_5 = tkinter.Label(self, text="CashOut rápido", font=("bold", 10))
        label_5.place(x=10, y=170)
        self.var1 = tkinter.IntVar()
        tkinter.Radiobutton(self, text="Não", padx=5, variable=self.var1, value=1).place(x=135, y=170)
        tkinter.Radiobutton(self, text="Sim", padx=20, variable=self.var1, value=2).place(x=190, y=170)
        self.var1.set(self.settings.fast_cash)

        label_6 = tkinter.Label(self, text="Criptografar apostas", font=("bold", 10))
        label_6.place(x=10, y=200)
        self.var2 = tkinter.IntVar()
        tkinter.Radiobutton(self, text="Não", padx=5, variable=self.var2, value=1).place(x=135, y=200)
        tkinter.Radiobutton(self, text="Sim", padx=20, variable=self.var2, value=2).place(x=190, y=200)
        self.var2.set(self.settings.criptografia)

        label_7 = tkinter.Label(self, text="Loop CashOut", font=("bold", 10))
        label_7.place(x=10, y=230)
        self.var3 = tkinter.IntVar()
        tkinter.Radiobutton(self, text="Não", padx=5, variable=self.var3, value=0).place(x=135, y=230)
        tkinter.Radiobutton(self, text="Sim", padx=20, variable=self.var3, value=1).place(x=190, y=230)
        self.var3.set(self.settings.cashout_dynamic)

        tkinter.Button(self, text='Salvar', width=15, height=2, bg='#8398FC', fg='white', command=self.saveChanges).place(x=360, y=180)

        label_lc = tkinter.Label(self, text="Selecione a aposta para o CashOut", font=("bold", 10))
        label_lc.place(x=140, y=280)
        self.list_cash = ttk.Combobox(self)
        self.list_cash.place(x=10, y=310, width=470)
        self.list_cash.current()
        self.list_cash.bind('<<ComboboxSelected>>', self.setVariableCash)

        tkinter.Button(self, text='Atualizar Lista', width=20, bg='orange', fg='white',
                       command=self.atualizarListaCash).place(x=70, y=350)
        tkinter.Button(self, text='CashOut Manual', width=20, bg='#28D25B', fg='white',
                       command=self.cashOutForcado).place(x=250, y=350)

        # tkinter.Button(self, text='Salvar Alterações', width=20, bg='#8398FC', fg='white', command=self.saveChanges).place(x=120, y=320)
        tkinter.Button(self, text='Conexões', width=15, command=self.listClientsConnecteds).place(x=185, y=400)
        tkinter.Button(self, text='Iniciar', width=15, command=self.startServer).place(x=40, y=400)
        tkinter.Button(self, text='Sair', width=15, bg='brown', fg='white', command=self.exit).place(x=330, y=400)
        tkinter.Button(self, text='Forçar Reinicialização', width=20, bg='#8398FC', fg='white', command=self.restartClients).place(x=70, y=450)
        tkinter.Button(self, text='Resetar Clientes', width=20, bg='#8398FC', fg='white', command=self.resetClients).place(x=250, y=450)
        self.label_04 = tkinter.Label(self, text="0 Usuários Conectados")
        self.label_04.place(x=10, y=510)
        self.label_04.configure(foreground='red')

    def cashOutForcado(self):
        if self.started:
            data = {'cod': 15, 'id': self.cash_id, 'fast_bet': True, 'bg': self.cash_bg, 'personalizada': self.personalizada}
            print(data)
            if self.var2.get() == 1:
                self.server.socket_server.sendToAll(data)
            else:
                self.server.socket_server.sendToAll(encrypt(data))

            if server_settings.USE_GROUP_TIPS:
                if not self.last_cash == self.cash_bg:
                    self.last_cash = self.cash_bg
                    message = '*CASHOUT:*\n\n{}\n\n'.format(self.time)
                    try:
                        bot = telepot.Bot(server_settings.BOT_ID)
                        group_id = server_settings.GROUP_TIPS_ID
                        bot.sendMessage(group_id, message, parse_mode='Markdown')
                    except:
                        pass

    def setVariableCash(self, event):
        self.cash_id = self.list_cash.get().split('ID: ')[1].split(' > BG: ')[0]
        self.cash_bg = self.list_cash.get().split('BG: ')[1].split(' > ')[0]
        self.personalizada = True if 'BETBUILDER' in self.list_cash.get().split(' > ')[1] else False
        self.time = self.list_cash.get().split(' > ')[1].split(' > ')[0]
        if 'BETBUILDER' in self.time:
            self.time = self.time.split('BETBUILDER - ')[1]

    def atualizarListaCash(self):
        self.cash_id = None
        self.cash_bg = None
        if self.started:
            con = sqlite3.connect('dbserver.sqlite3_bmclub')
            cur = con.cursor()
            query = cur.execute('SELECT * FROM apostas;')
            query = query.fetchall()
            lista = []
            for aposta in query[-60:]:
                try:
                    lista.insert(0, aposta[3] + ' > ' + aposta[4] + ' > ' + aposta[5] + ' > ID: ' + aposta[1] + ' > BG: ' + aposta[2])
                except:
                    pass
            lista.insert(0, '')
            self.list_cash['values'] = lista
            self.list_cash.current(0)

    # see source mitmproxy/master.py for details
    def loop_in_thread(self, loop, m):
        asyncio.set_event_loop(loop)  # This is the key.
        m.run_loop(loop.run_forever)

    def startServer(self):
        if not self.started:
            stake_localhost = self.entry_1.get() if self.entry_1.get() else 1
            stake_tipster = self.entry_2.get() if self.entry_2.get() else 1
            max_units = self.entry_3.get() if self.entry_3.get() else 1
            fast_bet = self.var.get()
            fast_cash = self.var1.get()

            hosts = ['^(?![0-9\.]+:)(?!([^\.:]+\.)*bet365\.com:)']

            options = Options(listen_host='0.0.0.0', listen_port=self.my_port, http2=True, ignore_hosts=hosts)
            m = DumpMaster(options, with_termlog=False, with_dumper=False)
            config = ProxyConfig(options)
            m.server = ProxyServer(config)
            m.addons.add(block)
            m.options.set('block_global=false')
            # Autenticação pelo arquivo de pass do apache
            # m.options.set('proxyauth=@.htpasswd')
            # Autenticação por single user
            # m.options.set('upstream_auth=jonas:jp130281')

            self.server = Addon(stake_localhost, stake_tipster, fast_bet, fast_cash, max_units)

            m.addons.add(self.server)
            loop = asyncio.get_event_loop()
            t = threading.Thread(target=self.loop_in_thread, args=(loop, m))
            t.daemon = True
            t.start()
            self.label_02['text'] = 'Online'
            self.label_02.configure(foreground='green')
            self.started = True
            self.getClientsConnecteds()

    def showMessage(self, message, type):
        self.label_01['text'] = message
        if type == 1:
            self.label_01.configure(foreground='green')
        else:
            self.label_01.configure(foreground='red')
        time.sleep(5)
        self.label_01['text'] = ''

    def restartClients(self):
        pass
        # self.server.socket_server.sendToAll({'cod': 95, 'text': 'Reiniciando o sistema na versão 1.32 ou superior'})

    def resetClients(self):
        self.server.socket_server.sendToAll({'cod': 96, 'text': 'Reiniciando o sistema na versão 1.2 ou superior'})

    def saveChanges(self):
        self.settings.stake_localhost = self.entry_1.get() if self.entry_1.get() else 1
        self.settings.stake_tipster = self.entry_2.get() if self.entry_2.get() else 1
        self.settings.max_units = self.entry_3.get() if self.entry_3.get() else 1
        self.settings.fast_bet = self.var.get()
        self.settings.fast_cash = self.var1.get()
        self.settings.criptografia = self.var2.get()
        self.settings.cashout_dynamic = self.var3.get()

        success = self.settings.updateSettings(id=1)
        if success:
            thread1 = threading.Thread(target=self.showMessage, args=('Alterações Realizadas com Sucesso', 1))
            thread1.daemon = True
            thread1.start()
            if self.started:
                self.server.updateVariables(self.entry_1.get(), self.entry_2.get(), self.var.get(), self.var1.get(), self.entry_3.get(), self.var2.get())
        else:
            thread1 = threading.Thread(target=self.showMessage, args=('As Alterações Não Foram Realizadas', 2))
            thread1.daemon = True
            thread1.start()

    def exit(self):
        sys.exit(1)

def resource_path(relative_path):
    base_path = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base_path, relative_path)

image_path = resource_path("bm_server.png")
root = tkinter.Tk()
root.geometry('500x550+110+50')
root.resizable(False, False)
p1 = tkinter.PhotoImage(file=image_path)
root.iconphoto(False, p1)
client = GuiPart(root, image_path)
root.mainloop()
